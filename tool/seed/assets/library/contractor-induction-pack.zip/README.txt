Contractor induction pack: policy, sign-in sheet and the induction deck are in this archive.
